var button_0 = document.getElementById("button_0");
var button_1 = document.getElementById("button_1");
var button_2 = document.getElementById("button_2");
var button_3 = document.getElementById("button_3");

var image = document.getElementById("image");

button_0.addEventListener("click", function(){
    image.src = "images/bg0.jpg"
});

button_1.addEventListener("click", function(){
    image.src = "images/bg1.jpg"
});

button_2.addEventListener("click", function(){
    image.src = "images/bg2.jpg"
});

button_3.addEventListener("click", function(){
    image.src = "images/bg3.jpg"
});