var dagen = ["maandag" , "dinsdag", "woensdag" , "donderdag", "vrijdag", "zaterdag", "zondag"]

document.getElementById("alledagen").innerHTML = dagen.join(" - ");

for(s=0; s<=4; s++){
    if(s != 4){
        document.getElementById("allewerkdagen").innerHTML += dagen[s].join ( " - ");
    } else {
        document.getElementById("alleweekenddagen").innerHTML += dagen[s]
    }
}