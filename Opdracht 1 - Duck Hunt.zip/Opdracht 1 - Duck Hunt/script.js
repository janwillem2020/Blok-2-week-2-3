var hit = 0
var miss = 0
var duck = document.getElementById("duck");
var stage = document.getElementById("stage")
//                 0     1    2    3     4     5    6    7    
var richtingen = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
var posLeft = 500;
var posTop = 200;

function HitCounter() {
    document.getElementById("hit").innerHTML = hit++ + 1;
}

function MissCounter() {
    document.getElementById("miss").innerHTML = miss++ + 1;
}

function moveDuck(){
    var number = Math.floor(Math.random() * richtingen.length);
    var richting = richtingen[number];
    if (richting == "N") {
        posTop = posTop - 75;
        duck.style.top = posTop + "px"

        if (posTop < 0) {
            posTop = 600;
        }
    }

    else if (richting == "NE") {
        posTop = posTop - 75;
        duck.style.top = posTop + "px"
        posLeft = posLeft + 75;
        duck.style.left = posLeft + "px"
    }

    else if (richting == "E") {
        posLeft = posLeft + 75
        duck.style.left = posLeft + "px"

        if (posLeft > 1030) {
            posLeft = 0;
        }
    }

    else if (richting == "SE") {
        posLeft = posLeft + 75
        duck.style.left = posLeft + "px"
        posTop = posTop + 75;
        duck.style.top = posTop + "px"
    }

    if (richting == "S") {
        posTop = posTop + 75;
        duck.style.top = posTop + "px"

        if (posTop > 519) {
            posTop = 0;
        }
    }

    else if (richting == "SW") {
        posLeft = posLeft - 75
        duck.style.left = posLeft + "px"
        posTop = posTop + 75;
        duck.style.top = posTop + "px"
    }
    
    if (richting == "W") {
        posTop = posTop + 75;
        duck.style.top = posTop + "px"

        if (posLeft < 0) {
            posLeft = 1030;
        }
    }

    else if (richting == "NW") {
        posLeft = posLeft - 75
        duck.style.left = posLeft + "px"
        posTop = posTop - 75;
        duck.style.top = posTop + "px"
    }
}

(function theLoop (i) {
  setTimeout(function () {
    moveDuck()
    if (--i) {          
      theLoop(i);      
    }
  }, 500);
})(1000000000);